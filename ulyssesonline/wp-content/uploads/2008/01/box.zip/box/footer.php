<div id="footer">
<p>
    Copyright &#169; 2008 <a href="http://ulyssesonline.com">Ulysses Ronquillo</a>. All rights reserved. <br />
    Powered by <a href="http://wordpress.org">WordPress</a> v <?php bloginfo("version"); ?>.
    Page in <?php timer_stop(1); ?> seconds. <br />
    <a href="http://ulyssesonline.com">The Box Theme</a>. 
</p>
</div>
</div>
	<?php wp_footer(); ?>
</body>
</html>
