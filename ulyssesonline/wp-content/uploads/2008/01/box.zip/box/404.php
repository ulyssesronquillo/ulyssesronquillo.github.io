<?php get_header(); ?>

<?php get_sidebar(); ?>

	<div id="content" class="narrowcolumn">

		<h2 class="center">Page Not Found</h2>
		<p class="center">Sorry, but you are looking for something that isn't here.</p>
		<p class="center">Please try the Search feature again.</p>
		
		<?php include (TEMPLATEPATH . '/searchform.php'); ?>

	</div>

<?php get_footer(); ?>