<?php get_header(); ?>

<div id="content" class="narrowcolumn">

	<h2>404: File Not Found</h2>
	
	<p>Looking for something?</p>
	<p><?php include (TEMPLATEPATH . '/searchform.php'); ?></p>

	<br /><br /><br /><br /><br /><br /><br /><br />

</div>

<?php get_footer(); ?>
