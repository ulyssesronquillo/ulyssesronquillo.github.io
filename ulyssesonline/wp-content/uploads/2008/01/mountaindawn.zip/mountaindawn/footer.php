<div id="footer">

	<p class="center">
	
Admin: <?php if (is_user_logged_in()) { ?> <a href="<?php bloginfo('wpurl'); ?>/wp-admin/">Dashboard</a> &#183; <?php } else { } ?> <?php wp_loginout(); ?><br />
Feed: <a href="http://ulyssesonline.com/feed/">RSS Entries</a> &#183; <a href="http://ulyssesonline.com/comments/feed/">RSS Comments</a><br />
Copyright &#169; 2008. <a href="http://ulyssesonline.com">Ulysses Ronquillo</a>. All rights reserved.<br />
Powered by <a href="http://wordpress.org">WordPress</a> v <?php bloginfo("version"); ?>. Page in <?php timer_stop(1); ?> seconds.<br />
Theme: <a href="http://ulyssesonline.com">Mountain Dawn</a>

	</p>
	
</div>

</div>

<?php do_action('wp_footer'); ?>

</body>
</html>
