INSTRUCTIONS

1. Upload the theme to your 'wp-content/themes/' folder.

2. Create a new WordPress Page called "Sitemap" using the Sitemap Template. Add Widgets to the new "Sitemap" Page. Save the changes.

3. If you want to edit menu tabs in the header, edit the header.php file.

4. That's it.


HEADER IMAGE

If you are curious about how I change the header text to an image, well, I'm using a php program called Titles that converts text to an image. This theme uses alien.tff, a true type font from the movie 'Alien.' If you want to use a different true font type, just download it from the internet and place it in the theme directory. Just edit the headerimage.php file and change the reference to './alien.ttf' to your new TTF file. Refresh your browser to see the changes.

If you have any questions, contact me at 'ulyssesr@yahoo.com."

Ulysses
