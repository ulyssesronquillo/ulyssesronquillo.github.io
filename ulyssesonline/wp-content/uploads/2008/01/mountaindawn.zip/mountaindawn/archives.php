<?php
/*
Template Name: Archives
*/
?>

<?php get_header(); ?>

<div id="content" class="narrowcolumn">

	<div class="pagepost">
	
	<div class="entrytext">
	
	<h2>Archives</h2>

	<?php include (TEMPLATEPATH . "/searchform.php"); ?>

	<h3>Last 10 Posts</h3>
	  <ul>
	      <?php get_archives('postbypost', '10', 'other', '<li>', '</li>', false); ?>
	  </ul>
	  
	<h3>Archives by Month:</h3>
	  <ul>
	    <?php wp_get_archives('type=monthly'); ?>
	  </ul>

	<h3>Archives by Year</h3>
	 <ul>
	<?php $years = $wpdb->get_col("SELECT DISTINCT YEAR(post_date) FROM $wpdb->posts WHERE post_status = 'publish' ORDER BY post_date DESC");
        foreach($years as $year) : ?>
	    <li><a href="<?php echo get_year_link($year); ?> "><?php echo $year; ?></a></li>
	<?php endforeach; ?>
	</ul>

	<h3>Archives by Subject:</h3>
	  <ul>
	     <?php wp_list_cats(); ?>
	  </ul>

        </div>

	</div>
</div>

<?php get_footer(); ?>
