<?php
/*
Template Name: Sitemap
*/
?>

<?php get_header(); ?>

<div id="content" class="narrowcolumn">

<div id="sidebar">

   <div class="embed">

   <ul>

   <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>
   
   <p>You have successfully created a Sidebar 1!</p>
   
   <p>Go to <a href="<?php echo get_settings('siteurl'); ?>/wp-admin/">Admin Dashboard</a> and click on Presentation menu. Click Widgets and add some Widgets to this Page. This page will disappear when widgets are added. That's it.</p>

   <?php endif; ?>
   
   </ul>
   
   </div>

   <div class="embed">

   <ul>

   <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : else : ?>
   
   <p>You have successfully created a Sidebar 2!</p>
   
   <p>Go to <a href="<?php echo get_settings('siteurl'); ?>/wp-admin/">Admin Dashboard</a> and click on Presentation menu. Click Widgets and add some Widgets to this Page. This page will disappear when widgets are added. That's it.</p>

   <?php endif; ?>
   
   </ul>
   
   </div>

   <div class="clear"></div>

</div>

</div>

<?php get_footer(); ?>
