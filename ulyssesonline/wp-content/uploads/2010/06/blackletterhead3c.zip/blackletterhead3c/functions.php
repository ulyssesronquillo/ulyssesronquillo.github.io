<?php

/* Widgets */

if ( function_exists('register_sidebar') )
register_sidebar(array('name'=>'sidebar1',
'before_widget' => '',
'after_widget' => '',
'before_title' => '<h2>',
'after_title' => '</h2>',
));
register_sidebar(array('name'=>'sidebar2',
'before_widget' => '',
'after_widget' => '',
'before_title' => '<h2>',
'after_title' => '</h2>',
));

/* End of Widgets */

/* Legacy Comments */

add_filter('comments_template', 'legacy_comments');
function legacy_comments($file) {
	if(!function_exists('wp_list_comments')) 	$file = TEMPLATEPATH . '/legacy.comments.php';
	return $file;
}

/* End of Legacy Comments */

/* Post Thumbnails */

if ( function_exists( 'add_theme_support' ) )
     add_theme_support( 'post-thumbnails' );

/* End of Post Thumbnails */

?>