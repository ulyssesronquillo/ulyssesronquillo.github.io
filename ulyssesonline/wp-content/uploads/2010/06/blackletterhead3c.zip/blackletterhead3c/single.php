<?php get_header(); ?>

  <div id="content" class="narrowcolumn">
				 
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
		<div class="post">
		
		<div class="navigation">
			<div class="alignleft"><?php previous_post('&laquo; %','','yes') ?></div>
			<div class="alignright"><?php next_post(' % &raquo;','','yes') ?></div>
		</div>		
				
			<h2 id="post-<?php the_ID(); ?>"><a href="<?php echo get_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a></h2>	

			<small><?php the_time('F jS, Y'); ?> by <?php the_author(); ?></small>		

			<div class="entry">

				<?php if (function_exists('the_post_thumbnail')) {the_post_thumbnail('post-thumbnail');} ?>

				<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>
	
				<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
				
				<small><?php the_tags('Tags: ', ', ', '<br />'); ?></small>
				<small>Categories: <?php the_category(', '); ?></small>				
	
				<p><small><?php edit_post_link('Edit this entry.','',''); ?></small></p>
	
			</div>
		</div>
		
	<?php comments_template(); ?>
	
	<?php endwhile; else: ?>
	
		<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
	
<?php endif; ?>
	
  </div>

<?php get_sidebar(); ?>  
  
<?php get_footer(); ?>
