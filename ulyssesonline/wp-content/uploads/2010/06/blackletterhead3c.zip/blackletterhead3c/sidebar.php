	<div id="sidebar">
		<ul>

		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar1') ) : ?>

		<li><h2>Activate Widgets</h2>
		<li>From the Dashboard, go to Appearance > Widgets and drag the Available Widgets to the Sidebars. This message will disappear when you activate a widget. Enjoy.</li>
		
		<?php endif; ?>

		</ul>
	</div>
	
	<div id="sidebar2">
		<ul>

		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar2') ) : ?>

		<li><h2>Activate Widgets</h2>
		<li>From the Dashboard, go to Appearance > Widgets and drag the Available Widgets to the Sidebars. This message will disappear when you activate a widget. Enjoy.</li>
		
		<?php endif; ?>		

		<h2><a href="javascript:;" onmousedown="toggleSlide('mydiv');">Preferences</a> &larr;click</h2>		
		
        <div id="mydiv" style="display:none; overflow:hidden; height:40px;">
        
			<ul>
				<li>Choose a Color</li>
                <li> 
                    <a href="#" onclick="setActiveStyleSheet('style'); return false;">O</a> &middot
                    <a href="#" onclick="setActiveStyleSheet('red'); return false;">R</a> &middot
                    <a href="#" onclick="setActiveStyleSheet('blue'); return false;">B</a> &middot
                    <a href="#" onclick="setActiveStyleSheet('green'); return false;">G</a> &middot
                    <a href="#" onclick="setActiveStyleSheet('yellow'); return false;">Y</a> &middot
                    <a href="#" onclick="setActiveStyleSheet('purple'); return false;">P</a> &middot
                    <a href="#" onclick="setActiveStyleSheet('teal'); return false;">T</a>
                </li>
			</ul>
				
		</div>				
		
       	</ul>
	</div>
