<div id="footer">
	<p class="center">
	Copyright &#169; 2003-2010. All rights reserved. <br />
	Theme: <a href="http://ulyssesonline.com">Black-Letterhead-3RC</a>.  <br />
	Page in <?php timer_stop(1); ?> seconds.
	</p>
</div>
</div>

<?php do_action('wp_footer'); ?>

</body>
</html>
