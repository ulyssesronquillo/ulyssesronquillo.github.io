<?php
// Image generation from Text String
// Created by Patrick Stuart www.patrickstuart.com
// Copyright 2004, released under GPL, distribute as needed
// Call from a file <img src="titles.php?letters=Insert Text Here" />
// Use at own risk, requires GD library and FreeType Library and PHP

$letters = $_GET['letters'];
$letter = urldecode(urldecode($letters)); 	// Do not edit
$letter = str_replace('_', ' ', $letter); 	// Do not edit
$letter = str_replace('.png', '', $letter);	// Do not edit

$font = './boston.ttf';			// Edit this line to the path and file of the font you want to use
	 					// Good resource for free fonts - http://www.webpagepublicity.com/free-fonts.html

$txt_size = 16; 	// Size of Text
$x_margin = 5; 		// Set Margin of x of text
$y_margin = 10; 	// Set Margin of y of text
$txt_angle = 0;		// Angle of Text
$shdw_angle = 0;	// Angle of Text Shadow
$shdw_x_offset = 1;	// Horizontal Shadow offset
$shdw_y_offset = 1;	// Vertical Shadow offset
$bg_r = 255;  		// Background Color Red
$bg_g = 255;   		// Background Color Green
$bg_b = 255;    	// Background Color Blue
$txt_r = 51;  		// Text Color Red
$txt_g = 51;    	// Text Color Green
$txt_b = 51;    	// Text Color Blue
$shdw_r = 255;  	// Text Shadow Color Red
$shdw_g = 255;    	// Text Shadow Color Green
$shdw_b = 255;    	// Text Shadow Color Blue

//Do Not Edit Below

$bounds = imagettfbbox($txt_size,0,$font,$letter); 			// Do not edit Calculates Bounding points of box as array
$image_x = (2 * $x_margin) + $bounds[2]; 				// Do not edit Calculates Width of Box based on String Length and Margin
$image_y = $txt_size + (2 * $y_margin);					// Do not edit Calculates Height of Box based on Text Size and Margin

$txt_x = ($image_x  - ($x_margin))/2 - ($bounds[2]/2); 			// Calculates Horizontal Position of box centered
$txt_y = ($image_y - (($image_y - $txt_size) / 2)) - ($y_margin/4); 	// Calculates Vertical Postion of box centered
$shdw_x = $shdw_x_offset + (($image_x  - ($x_margin))/2 - ($bounds[2]/2));	// Shadow Horizontal Calculation
$shdw_y = $shdw_y_offset + (($image_y - (($image_y - $txt_size) / 2))) - ($y_margin/4); // Shadow Vertical Calculation
$im = imagecreate ($image_x, $image_y); // Creates image box
$txt_background = imagecolorallocate ($im, $bg_r, $bg_g, $bg_b); // Background
$txt_Color = imagecolorallocate ($im, $txt_r, $txt_g, $txt_b); // Text
$shadow_Color = imagecolorallocate ($im, $shdw_r, $shdw_g, $shdw_b); // Drop Shadow
imagettftext ($im, $txt_size, $shdw_angle, $shdw_x, $shdw_y, $shadow_Color, $font, $letter); // Draw Text shadow
imagettftext ($im, $txt_size, $txt_angle, $txt_x, $txt_y, $txt_Color, $font, $letter); // Draw Text

// Output file as png
header('Content-Type: image/png');
imagePNG($im);
imagedestroy ($im);
?>
