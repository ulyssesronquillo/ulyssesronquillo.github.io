<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<div><input type="text" placeholder="<?php echo esc_attr_e('Search', 'blackletterhead'); ?>" name="s" id="s" />
<input type="submit" id="searchsubmit" value="<?php echo esc_attr_e('Search', 'blackletterhead'); ?>" />
</div>
</form>