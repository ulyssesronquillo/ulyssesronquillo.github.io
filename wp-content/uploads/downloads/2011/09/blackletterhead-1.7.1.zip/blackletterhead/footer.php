<div id="footer">
  <p class="center">
  Copyright &#169; 2003-2010. All rights reserved. Theme: <a href="http://ulyssesonline.com">Black-Letterhead</a>.<br />
  Powered by <a href="http://wordpress.org">WordPress</a> v <?php bloginfo("version"); ?>.  
  Page in <?php timer_stop(1); ?> seconds.
  </p>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>
