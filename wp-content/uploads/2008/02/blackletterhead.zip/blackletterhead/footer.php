<div id="footer">
	<p class="center">

                Copyright &#169; 2003-2008 <a href="http://ulyssesonline.com">Ulysses Ronquillo</a>. All rights reserved. <br />
                Powered by <a href="http://wordpress.org">WordPress</a> v <?php bloginfo("version"); ?>.  
		Page in <?php timer_stop(1); ?> seconds.
	</p>
</div>
</div>

<?php do_action('wp_footer'); ?>

</body>
</html>