<?php get_header(); ?>

<div id="content" class="widecolumn">

<div id="basic-accordian" ><!--Parent of the Accordion-->
 
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
	<div class="post">
			
	<h2 id="post-<?php the_ID(); ?>"><a href="<?php echo get_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a></h2>	
	
	        <small><?php the_time('D. F j, Y'); ?></small><br />
            <small>Categories: <?php the_category(', '); ?></small><br />
	        <small><?php the_tags('Tags: ', ', ', '<br />'); ?></small>

	<div class="entrytext">
		<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>
		<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>	
    </div>
	</div>
	
	<div class="comments_template">
	  <div class="wrapper">
		<?php comments_template(); ?>
	  </div>
	</div>
	
	<?php endwhile; else: ?>
	
		<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
	
    <?php endif; ?>

</div>

</div>

<?php get_footer(); ?>
