<?php get_header(); ?>
<!-- borrowed directly from Kubrick -->

<div id="content" class="widecolumn">

<div id="basic-accordian" ><!--Parent of the Accordion-->

<div class="tab_container">
  <div id="home-header" class="accordion_headings header_highlight" >Recent</div>
  <div id="menu-header" class="accordion_headings" >Archive</div>
  <div id="search-header" class="accordion_headings" >Search</div>
</div>

<div style="float:left;">
  <div id="home-content">
    <div class="accordion_child">

	<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>
				
                <div class="post">
                <span class="postdate"><?php the_time('m.d.y') ?></span> - <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                </div>
	
		<?php endwhile; ?>

		<div class="navigation">
			<div class="alignleft"><?php posts_nav_link('','','&laquo; Previous Entries') ?></div>
			<div class="alignright"><?php posts_nav_link('','Next Entries &raquo;','') ?></div>
		</div>
	
	<?php else : ?>

		<h2 class="center">Search not found. Try again.</h2>
		<div id="sidebar">
		<?php include (TEMPLATEPATH . "/searchform.php"); ?>
		</div>

	<?php endif; ?>

    </div>
  </div>

  <div id="menu-content">    <div class="accordion_child">
    <div id="sidebar">
    <div class="embed">
    <ul><?php wp_list_pages(''); ?></ul>
    <ul><?php wp_list_categories();?></ul>
    </div>
    <div class="embed">
    <ul><li>Archives
    <ul><?php wp_get_archives('type=monthly&limit=30'); ?></ul>
    </li><ul>
    </div>
    <div class="clear"></div>
    </div>
    </div>
  </div>

  <div id="search-content">    <div class="accordion_child">
    <div id="sidebar">
    <?php include (TEMPLATEPATH . "/searchform.php"); ?>
    </div>
    </div>
  </div>

</div>
</div><!--End of accordion parent-->

</div>

<?php get_footer(); ?>
