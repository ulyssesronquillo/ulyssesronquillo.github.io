<div id="footer">
  <p class="center">
  Copyright &#169; 2003-2008 <a href="http://ulyssesonline.com">Ulysses Ronquillo</a>. 
  </p>
</div>
</div>
<?php do_action('wp_footer'); ?>
</body>
</html>