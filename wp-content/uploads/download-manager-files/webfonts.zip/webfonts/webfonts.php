<?php

/*
Plugin Name: Web Fonts
Plugin URI: http://uly.me/google-web-fonts-plugin/
Description: Utilize Google Webfonts in WordPress.
Version: 1.1
Author: Ulysses Ronquillo
Author URI: http://uly.me
*/

// include main file

function urr_google_webfonts() {
	include('urr_main.php');
}

// add this plugin under the appearance theme pages

add_action( 'admin_menu', 'urr_google_webfonts_add_options' );

function urr_google_webfonts_add_options() {
	add_theme_page( 'Web Fonts', 'Web Fonts', 'manage_options', __FILE__, 'urr_google_webfonts' );
}

// add this plugin in the admin bar menu

//add_action('admin_bar_menu', 'add_toolbar_items', 100);

function add_toolbar_items($admin_bar){

	$admin_bar->add_menu( array(
		'id'    => 'web-fonts',
		'title' => 'Web Fonts',
		'href'  => admin_url('options-general.php?page=webfonts/webfonts.php'),	
		'meta'  => array(
			'title' => __('Web Fonts'),			
		),
	));
	
}

// add code to the wp_head section

function urr_webfonts_header() {
	//get options
	$name = get_option('urr_webfont_name');
	$style = get_option('urr_webfont_style');
	// display to wp_head
	echo stripslashes($name);
	echo '<style>'.stripslashes($style).'</style>';
}

add_action( 'wp_head', 'urr_webfonts_header' );

/* end of webfonts.php */